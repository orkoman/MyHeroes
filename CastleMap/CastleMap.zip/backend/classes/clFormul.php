<?php
/**
 * Created by PhpStorm.
 * User: z002y7ua
 * Date: 10.03.2015
 * Time: 14:18
 */

class clFormul {

    public static function calculate_maxAmount($_storesArray)
    {
        $result = 1000; //start value
        if ($_storesArray != 0)
        {

        }
        return $result;
    }

    public static function calculate_buildTime($_building_id)
    {
        $result = 0; //start value
        //if ($_storesArray != 0)
        {

        }
        return $result;
    }
}