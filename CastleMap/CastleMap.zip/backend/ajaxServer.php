<?php
/**
 * Created by PhpStorm.
 * User: z002y7ua
 * Date: 09.03.2015
 * Time: 18:03
 */

include_once "classes/clServer.php";

session_start();

$type = $_GET["t"];

switch ($type) //return buildings that can be build
{
    case 1: { //return buildings that can be build
        $player_id = $_SESSION["id"];

        if (dbConnection::connect()) {
            //TODO put it in clServer
            $sql = "SELECT name,size,buildTimeInMin,startHitpoints FROM buildings where name != 'castle'";
            clServer::safeReturn(clServer::getSomething($sql));
        }
    }break;
    case 2: { //return buildings that can be build
        $position = $_GET["p"];
        $name = $_GET["n"];
        clServer::safeReturn($position."_".$name);

    }break;
    default: {
        print "ERROR";
    }
}

?>