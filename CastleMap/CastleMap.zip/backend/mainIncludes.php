<?php
/**
 * Created by PhpStorm.
 * User: Z002Y7UA
 * Date: 27.02.2015
 * Time: 12:19
 */
define ('MAINDIR', "D:/Projects/CastleMap");
define ('MAINURI', "http://localhost");




?>