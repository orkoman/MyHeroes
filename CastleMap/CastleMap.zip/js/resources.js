function clResource(_dataArr,_extraArg)
{
    this.m_name = _dataArr[0];
    this.m_amount = _dataArr[1];
    this.m_profit = _dataArr[2];
    this.m_maxAmount = _dataArr[3];

    this.f_createDiv = createDiv;

    function createDiv(_left)
    {
        var divIcon = "<div class='resourceIcon' style=\"background-image:url('../img/icons/" + this.m_name + ".png');\"></div>";
        var divText = "<div class='resourceText'>" + this.m_amount + '/' + this.m_maxAmount + '(' + this.m_profit + ")</div>";
        return ("<div id = '" + this.m_name + "' style = 'left:" + _left + "px;top:" + 0 + "px;'>" + divIcon + divText + "</div>");
    }
}

function clResourceTab(_id,_resources)
{
	//this.puffer = 2;
	this.m_resourceDiv = document.getElementById(_id);
	this.m_size = 128;
    this.m_resources = decodeData(_resources,clResource,0); //0 - no _extraArg

	this.f_create = create;

	this.f_create();

	function create()
	{
		var temp = "";
        //create resources
        var count = this.m_resources.length;
        for(var n = 0; n < count;n++)
        {
            var x = n*this.m_size;
            temp += this.m_resources[n].f_createDiv(x);
        }
		//alert(temp);
		this.m_resourceDiv.innerHTML = temp;
	}
}

function clDragObject(_id,_name,_size)
{
    this.m_name = _name;
    this.m_dragDiv = document.getElementById(_id);
    this.m_size = _size;
}


function clActionTab(_id)
{
    this.m_actionDiv = document.getElementById(_id);
    this.m_dragObject = 0;

    this.f_createDragObject =
    function createDragObject(_name,_size)
    {
        this.m_actionDiv.innerHTML = "<div id = 'drag' class ='" + _name + "' onmousedown=\"map_click(event)\" ></div>";
        this.m_dragObject = new clDragObject('drag',_name,_size);
    }

    this.f_removeDragObject =
        function removeDragObject()
        {
            this.m_dragObject = 0;
            this.m_actionDiv.innerHTML = "";
        }

    this.f_show =
    function show(_actions, _p2Position)
    {
        if (_p2Position == -1)
        {
            _p2Position = new clPoint2(this.m_actionDiv.offsetLeft + this.m_actionDiv.offsetWidth/2,
                                        this.m_actionDiv.offsetTop + this.m_actionDiv.offsetHeight/2);

        }
        //alert(_p2Position.m_x);
        var x = 5;
        var y = 5;
        var temp = "";
        var size = 0;

        var count = _actions.length;
        for(var n = 0; n < count;n++)
        {
            temp += "<div class ='" + _actions[n].m_name + "' style = 'left:" + x + "px;top:" + y + "px;' onclick=\"" + _actions[n].m_action +"\"></div>";
            var tempSize = _actions[n].m_size*64;
            x += 5 + tempSize;
            if (size < tempSize)
            {
                size = tempSize;
            }
        }
        y += 5 + size;

        this.m_actionDiv.innerHTML = temp;

        this.m_actionDiv.style.width = x + "px";
        this.m_actionDiv.style.height = y + "px";

        this.m_actionDiv.style.left = (_p2Position.m_x - this.m_actionDiv.offsetWidth/2) + "px";
        this.m_actionDiv.style.top = (_p2Position.m_y - this.m_actionDiv.offsetHeight/2) + "px";

        //alert(temp);
    }

    this.f_close =
    function close()
    {
        this.m_actionDiv.innerHTML = "";
        this.m_actionDiv.style.width = 0 + "px";
        this.m_actionDiv.style.height = 0 + "px";
    }

}









